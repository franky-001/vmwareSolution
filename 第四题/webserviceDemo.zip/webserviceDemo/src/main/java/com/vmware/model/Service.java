package com.vmware.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Service {
	
	@Id
	@Column(name="serviceId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int serviceId;
	
	@Column(name="name")
	public String name;
	
	@Column(name="phoe")
	public String phoe;
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoe() {
		return phoe;
	}
	public void setPhoe(String phoe) {
		this.phoe = phoe;
	}

}
