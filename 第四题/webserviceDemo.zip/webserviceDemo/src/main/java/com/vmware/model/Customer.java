package com.vmware.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Customer {
	@Id
	@Column(name="customerId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    public int customerId;
	
	@Column(name="name")
    public String name;
	
	@Column(name="description")
    public String description;
    
    
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
