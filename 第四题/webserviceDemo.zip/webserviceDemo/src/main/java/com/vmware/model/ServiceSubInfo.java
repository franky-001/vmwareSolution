package com.vmware.model;

public class ServiceSubInfo {
	
	public String cusName;
	
	public String serName;

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getSerName() {
		return serName;
	}

	public void setSerName(String serName) {
		this.serName = serName;
	}

}
