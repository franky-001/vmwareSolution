package com.vmware.simple;

import java.io.DataOutput;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vmware.model.Customer;
import com.vmware.model.Relationship;
import com.vmware.model.Service;
import com.vmware.model.ServiceSubInfo;
 
@Controller
public class MyController {
	
	
	@Autowired
	public BaseDao baseDao;
 
	@GetMapping("/hello")
	@ResponseBody
	public String hello(){
		return "hello";
	}
	
	
	@GetMapping("/subscriptions")
	@ResponseBody
	public ServiceSubInfo [] queryAll (){
		//����������ŵ���resourceĿ¼��
		String sqlString="select c.name as cusName,s.name as serName from relationship  r , customer c ,service s where r.serviceId=s.serviceId and r.customerId=c.customerId;";
		ServiceSubInfo []  ret= baseDao.execSQL(sqlString, ServiceSubInfo.class);
		return ret;
	}
	
	@RequestMapping(value = "/getCustomer/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
    public Customer getCustomerById(@PathVariable int id) {
        return customerService.getCustomer(id);
    }
	
	@RequestMapping(value = "/addSubscriptions", method = RequestMethod.POST, headers = "Accept=application/json")
    public String addCustomer(@ModelAttribute("customer") Customer customer,@ModelAttribute("service") Service service) {  
       Relationship r=new Relationship();
       r.setCustomerId(customer.getCustomerId());
       r.setServiceId(service.getServiceId());
       baseDao.save(r);
       return "";
    }
	
	@RequestMapping(value = "/delSubscriptions", method = RequestMethod.DELETE, headers = "Accept=application/json")
    public String delSubscriptions(@ModelAttribute("customer") Customer customer,@ModelAttribute("service") Service service) {  
      
       int customerId=customer.getCustomerId();
       int serviceId=service.getServiceId();
       String sqlString="select * from relationship  r , customer c ,service s where r.serviceId=s.serviceId and r.customerId=c.customerId and r.serviceId=? and r.customerId=?";
	   Object [] tmp=new Object[2];
	   tmp[0]=customerId;
	   tmp[1]=serviceId;
       ServiceSubInfo []  ret= baseDao.execSQL(sqlString, ServiceSubInfo.class,tmp);
       if(ret==null) {//ɾ��֮ǰ�ȿ��Ƿ����
    	   return "error";
       }else {
    	   baseDao.delete(ret[0]);
       }
       return "";
    }
	
	@RequestMapping(value = "/modifySubscriptions", method = RequestMethod.DELETE, headers = "Accept=application/json")
    public String modifySubscriptions(@ModelAttribute("customerId") int  customerId,  @ModelAttribute("oldServiceId") int  oldServiceId,@ModelAttribute("newServiceId") int  newServiceId ) {  
      
       i
       String sqlString="update relationship r  set r.serviceId=? where r.customerId=? and r.serviceId=?";
	   Object [] tmp=new Object[3];
	   tmp[0]=oldServiceId;
	   tmp[1]=customerId;
	   tmp[2]=newServiceId;
 
       return "";
    }
	
	
	
	
}
