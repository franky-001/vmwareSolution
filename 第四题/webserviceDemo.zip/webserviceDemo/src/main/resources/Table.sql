CREATE TABLE IF NOT EXISTS `relationship`(
   `id` INT UNSIGNED AUTO_INCREMENT,
   `serviceId` INT NOT NULL,
   `customerId` INT NOT NULL,
   PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `customer`(
   `customerId` INT UNSIGNED AUTO_INCREMENT,
   `name` varchar(50) ,
   `phone` varchar(50),
   PRIMARY KEY ( `customerId` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `service`(
   `serviceId` INT UNSIGNED AUTO_INCREMENT,
   `name` varchar(50) ,
   `description` varchar(50),
   PRIMARY KEY ( `serviceId` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;



select c.name,s.name from relationship r , customer c ,service s where r.serviceId=s.serviceId and r.customerId=c.customerId;